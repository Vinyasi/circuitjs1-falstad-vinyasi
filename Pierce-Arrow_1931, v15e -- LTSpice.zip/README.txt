Get LTSpice to run this file ...
Pierce-Arrow_1931, v15e - REGULATED.asc

Download link ...
http://www.linear.com/ltspice

Non-LTSpice files ...

CMF extension runs in CircuitMod ...

https://sourceforge.net/projects/circuitmod/

TXT extension runs in Paul Falstad's electronic simulator ...
http://falstad.com/circuit/
http://lushprojects.com/circuitjs/
http://vinyasi.info/ne

These three file types are binary text files.
They cannot be edited in Windows Notepad.

EditPadPro is an example of a binary text editor.

https://www.editpadpro.com/

But they can also be edited in their own simulator.

This compressed ZIP file has a shortcut for easy memory ...
http://is.gd/pierce_arrow_ltspice

