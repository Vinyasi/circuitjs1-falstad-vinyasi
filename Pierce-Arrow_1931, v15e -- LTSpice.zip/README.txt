Get LTSpice to run this file ...
Pierce-Arrow_1931, v15e - REGULATED.asc

Download link ...
http://www.linear.com/ltspice

Non-LTSpice files ...

CMF extension runs in CircuitMod ...

https://sourceforge.net/projects/circuitmod/

TXT extension runs in Paul Falstad's electronic simulator ...
http://falstad.com/circuit/
http://lushprojects.com/circuitjs/
http://vinyasi.info/ne

These three file types are binary text files.
They cannot be edited in Windows Notepad.

EditPadPro is an example of a binary text editor.

https://www.editpadpro.com/

But they can also be edited in their own simulator.

The compressed ZIP holding this file has a shortcut for easy memory ...
http://is.gd/pierce_arrow_ltspice
~or~
http://vinyasi.info/circuitjs1/!_zipped-files/Pierce-Arrow_1931,%20v15e%20--%20LTSpice.zip

This file may also be downloaded from these mirrors ...
These are uniquely different locations ...
https://is.gd/yegaco
~or~
https://archive.org/download/pc-sim-falstad-vinyasi/Pierce-arrow_1931V15e--Ltspice.zip

https://is.gd/benade
~or~
https://github.com/Vinyasi/circuitjs1-falstad-vinyasi/raw/master/Pierce-Arrow_1931%2C%20v15e%20--%20LTSpice.zip

https://is.gd/abawob
~or~
https://www.instructables.com/files/orig/F78/3LV3/JDOUMNCN/F783LV3JDOUMNCN.zip

https://is.gd/xepije
~or~
https://archive.org/download/HowToMakeAFreeEnergyDeviceWhichClonesMoreElectromagneticWaves/Pierce-arrow_1931V15e--Ltspice.zip

http://is.gd/aetherdollard
http://is.gd/refinedlmd
http://is.gd/teslaev
http://is.gd/teslaimpulse

http://is.gd/pierce_arrow
http://is.gd/pierce_arrow_cmf
http://is.gd/rapidpa
http://is.gd/rapidpa_cmf

There are an infinite variety of circuits possible to produce the exact same result.
This is based on Thevenin's Theorem of Equivalent Circuits ...
http://is.gd/thevenin
http://vinyasi.info/ne?startCircuit=thevenin.txt

http://is.gd/impulsedef
http://is.gd/teslacap
http://is.gd/pierce_arrow
http://is.gd/killgooselaygoldenegg
http://is.gd/whokilledev
http://is.gd/teslaradio



