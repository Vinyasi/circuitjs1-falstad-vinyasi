This is the same as version 4jm with one modification to CirSim ...
STEPSIM4jm.zip/circuitjs1-master/src/com/lushprojects/circuitjs1/client/CirSim.java

... on line 312: the addition of this line of code ...
setSimRunning(false);

... which has the effect of stopping the simulation after each time step.
You have to click the red START button in the upper right corner of the
simulator to restart the simulation for each subsequent time step. This
way, you can analyze what's happening moment to moment as the simulator
has been told how long a moment is by your having set the time frame
listed under 'Options' on the menubar. Now, you can attach a 'ADD Data
Export' component listed under 'Draw/Outputs and Labels/ADD Data Export'
listed on the menubar. After each time step, right-click this component
and save its data file. Compare the data among subsequent data files to
deduce what is happening at that node per time step.

This version of Paul Falstad's electronic simulator is available online
at ...

http://vinyasi.info/circuitjs1/!_zipped-files/STEPSIM4jm.zip

... and at GitHub.com ...

https://github.com/Vinyasi/circuitjs1-falstad-vinyasi

... and also at archive.org ...

https://archive.org/details/pc-sim-falstad-vinyasi

