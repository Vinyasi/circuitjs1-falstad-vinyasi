/*    
    Copyright (C) Paul Falstad and Iain Sharp
    Modified by Vinyasi 12/Sep/2018 17:01

// Mod.Begin
// Mod.End

    This file is part of CircuitJS1.

    CircuitJS1 is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    (at your option) any later version.

    CircuitJS1 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
*/

package com.lushprojects.circuitjs1.client;

//import java.awt.*;
//import java.util.StringTokenizer;

    class InductorElm extends CircuitElm {
	Inductor ind;
	double inductance;
// Mod.Begin
	double wireGauge;
	double wireGaugeConstant;
// Mod.End
	public InductorElm(int xx, int yy) {
	    super(xx, yy);
	    ind = new Inductor(sim);
	    inductance = 1;
// Mod.Begin
		wireGauge = 20;
		wireGaugeConstant = 0.003125;
//	    ind.setup(inductance, current, flags);
	    ind.setup(inductance, current, flags, wireGauge);
// Mod.End
	}
	public InductorElm(int xa, int ya, int xb, int yb, int f,
		    StringTokenizer st) {
	    super(xa, ya, xb, yb, f);
	    ind = new Inductor(sim);
	    inductance = new Double(st.nextToken()).doubleValue();
	    current = new Double(st.nextToken()).doubleValue();
// Mod.Begin
		try {
			wireGauge = new Double(st.nextToken()).doubleValue();
		} catch (Exception e) {
			wireGauge = 20;
		}
//	    ind.setup(inductance, current, flags);
	    ind.setup(inductance, current, flags, wireGauge);
// Mod.End
	}
	int getDumpType() { return 'l'; }
	String dump() {
// Mod.Begin
//	    return super.dump() + " " + inductance + " " + current;
	    return super.dump() + " " + inductance + " " + current + " " + wireGauge;
// Mod.End
	}
	void setPoints() {
	    super.setPoints();
	    calcLeads(32);
	}
	void draw(Graphics g) {
	    double v1 = volts[0];
	    double v2 = volts[1];
	    int i;
	    int hs = 8;
	    setBbox(point1, point2, hs);
	    draw2Leads(g);
	    setPowerColor(g, false);
	    drawCoil(g, 8, lead1, lead2, v1, v2);
	    if (sim.showValuesCheckItem.getState()) {
		String s = getShortUnitText(inductance, "H");
		drawValues(g, s, hs);
	    }
	    doDots(g);
	    drawPosts(g);
	}
	void reset() {
	    current = volts[0] = volts[1] = curcount = 0;
	    ind.reset();
	}
	void stamp() { ind.stamp(nodes[0], nodes[1]); }
// Mod.Begin
// in case I want to reattempt the elimination of a voltage difference if the coil is split into two coils counter wound to each other
//	volts[0] = volts[1] = ( volts[0] + volts[1] ) / 2;
// Mod.End
	void startIteration() {
	    ind.startIteration(volts[0]-volts[1]);
	}
	boolean nonLinear() { return ind.nonLinear(); }
	void calculateCurrent() {
	    double voltdiff = volts[0]-volts[1];
	    current = ind.calculateCurrent(voltdiff);
	}
	void doStep() {
	    double voltdiff = volts[0]-volts[1];
	    ind.doStep(voltdiff);
	}
	void getInfo(String arr[]) {
	    arr[0] = "inductor";
	    getBasicInfo(arr);
	    arr[3] = "L = " + getUnitText(inductance, "H");
// Mod.Begin
		arr[4] = "AWG = " + getUnitText(wireGauge, " ");
	    arr[5] = "SerR= " + getUnitText(ind.seriesResistance, sim.ohmString);
//	    arr[4] = "P = " + getUnitText(getPower(), "W");
	    arr[6] = "P = " + getUnitText(getPower(), "W");
// Mod.End
	}
// Mod.Begin >> I added this. It wasn't here before now.
	@Override
	String getScopeText(int v) {
	    return sim.LS("inductor") + ", " + getUnitText(inductance, "H");
	}
// Mod.End
	public EditInfo getEditInfo(int n) {
	    if (n == 0)
		return new EditInfo("Inductance (H)", inductance, 0, 0);
// Mod.Begin
	    if (n == 1)
		return new EditInfo("Wire Gauge: 1 to 80 (AWG)", wireGauge, 0, 0);
	    if (n == 2) {
// Mod.End
		EditInfo ei = new EditInfo("", 0, -1, -1);
		ei.checkbox = new Checkbox("Trapezoidal Approximation",
					   ind.isTrapezoidal());
		return ei;
	    }
	    return null;
	}
	
	public void setEditValue(int n, EditInfo ei) {
	    if (n == 0)
		inductance = ei.value;
// Mod.Begin
	    if (n == 1)
		wireGauge = ei.value;
//	    if (n == 1) {
	    if (n == 2) {
// Mod.End
		if (ei.checkbox.getState())
		    flags &= ~Inductor.FLAG_BACK_EULER;
		else
		    flags |= Inductor.FLAG_BACK_EULER;
	    }
// Mod.Begin
//	    ind.setup(inductance, current, flags);
	    ind.setup(inductance, current, flags, wireGauge);
// Mod.End
	}
	
	int getShortcut() { return 'L'; }
	
    }
