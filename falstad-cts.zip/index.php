<?PHP
  function getFileList($dir)
  {
    // array to hold return value
    $retval = array();

    // add trailing slash if missing
    if(substr($dir, -1) != "/") $dir .= "/";

    // open pointer to directory and read list of files
    $d = @dir($dir) or die("getFileList: Failed opening directory $dir for reading");
    while(false !== ($entry = $d->read())) {
      // skip hidden files
      if($entry[0] == ".") continue;
      if($entry == "index.php") continue;
      if($entry == "index.htm") continue;
      if($entry == "index.php_bak") continue;
      if($entry == "index.htm_bak") continue;
      if($entry == "space.gif") continue;
      if($entry == "blank.gif") continue;
      if($entry == "error_log") continue;
      if(is_dir("$dir$entry")) {
        $retval[] = array(
          "name" => "$dir$entry/",
          "type" => filetype("$dir$entry"),
          "size" => 0,
          "lastmod" => filemtime("$dir$entry")
        );
      } elseif(is_readable("$dir$entry")) {
        $retval[] = array(
          "name" => "$dir$entry",
          "type" => mime_content_type("$dir$entry"),
          "size" => filesize("$dir$entry"),
          "lastmod" => filemtime("$dir$entry")
        );
      }
    }
    $d->close();

    return $retval;
  }
?>
<?PHP
  // list files in the current directory
  $dirlist = getFileList(".");
  sort($dirlist);
?>
<!DOCTYPE html PUBLIC "-//IETF//DTD HTML 2.0//EN">
<!-- saved from url=(0031)http://vinyasi.info/circuitjs1/falstad-cts -->
<html><head>
<title>Index of /circuitjs1/falstad-cts</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<style>
    #link_barz a:link { color:#0000dd; background-color:#ffffff; }
    #link_barz a:visited { color:#607f60; background-color:#ffffff; }
    #link_barz a:hover { color:#ff0000; background-color:#ffff00; }
    #link_barz a:active { color:#ff0000; background-color:#ffff00; }
</style>
</head>
<body bgcolor="white">
<center>
<h1>
<span style=\"color:black;\">Index of /circuitjs1/falstad-cts</span>
 
<img src="http://vinyasi.info/smilies/angry.gif" alt="angry.gif" align="bottom" width="17" height="17" border="0" />
</h1>
</center>
<div id="link_barz" align="left">
<table cellspacing="3" cellpadding="5" border="1">
<tr>
<th>
Name
</th>
<th>
Last modified
</th>
<th>
Size
</th>
<th>
Description
</th>
</tr>
<tr>
<td colspan="4" style="font-weight:bold;">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
<a href="http://vinyasi.info/circuitjs1/">Parent Directory</a>
&nbsp;&ndash;&nbsp;
Sorted in order of file name.
</td>
</tr>
<?PHP
  // output file list
  foreach($dirlist as $file) {
    $alt = $file['name'];
    $alt = ltrim($alt,"./");
    $moddate = date("d F Y - h:i:sa", filemtime($alt));
      $desc = "Run <a href='http://vinyasi.info/ne?startCircuit=" . $alt . "' title='Run this circuit in the simulator devoid of any functional modifications made by me.'>" . $alt . "</a> in the simulator.<br />Run <a href='http://vinyasi.info/realsim?startCircuit=" . $alt . "' title='Run this circuit in a more realistic simulator in which all of the capacitors and coils have an internalized series resistance added to them.'>" . $alt . "</a> in the <a target='_blank' href='http://vinyasi.info/circuitjs1/graphs/real-bl.txt_.html' title='A list of all of the circuit simulations which are, or remain, overunity despite, or because of (in some cases), these modifications.'><i>realistic</i></a><i> simulator</i>.<br />Run <a href='http://vinyasi.info/stepsim?startCircuit=" . $alt . "' title='Run this circuit in the step simulator in which you have to repeatedly click the RUN button in the upper right corner to step the simulation through each time frame. This simulator also has series resistance added to its caps and coils.'>" . $alt . "</a> in the <i>step simulator</i>.";
    echo "<tr><td>\n";
    echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"{$file['name']}\">{$alt}</a>\n";
    echo "</td><td>\n";
    echo "{$moddate}\n";
    echo "</td><td>\n";
    echo "{$file['size']}\n";
    echo "</td><td>\n";
    echo "{$desc}\n";
    echo "</td></tr>\n";
  }
?>
</table>
<hr></pre></div>
</body>
</html>
