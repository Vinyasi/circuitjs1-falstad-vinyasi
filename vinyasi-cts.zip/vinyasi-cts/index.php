<?PHP
  function getFileList($dir)
  {
    // array to hold return value
    $retval = array();

    // add trailing slash if missing
    if(substr($dir, -1) != "/") $dir .= "/";

    // open pointer to directory and read list of files
    $d = @dir($dir) or die("getFileList: Failed opening directory $dir for reading");
    while(false !== ($entry = $d->read())) {
      // skip hidden files
      if($entry[0] == ".") continue;
      if($entry == "index.php") continue;
      if($entry == "index.htm") continue;
      if($entry == "index.php_bak") continue;
      if($entry == "index.htm_bak") continue;
      if($entry == "space.gif") continue;
      if($entry == "blank.gif") continue;
      if($entry == "error_log") continue;
      if(is_dir("$dir$entry")) {
        $retval[] = array(
          "name" => "$dir$entry/",
          "type" => filetype("$dir$entry"),
          "size" => 0,
          "lastmod" => filemtime("$dir$entry")
        );
      } elseif(is_readable("$dir$entry")) {
        $retval[] = array(
          "name" => "$dir$entry",
          "type" => mime_content_type("$dir$entry"),
          "size" => filesize("$dir$entry"),
          "lastmod" => filemtime("$dir$entry")
        );
      }
    }
    $d->close();

    return $retval;
  }
?>
<?PHP
  // list files in the current directory
  $dirlist = getFileList(".");
?>
<!DOCTYPE html PUBLIC "-//IETF//DTD HTML 2.0//EN">
<!-- saved from url=(0031)http://vinyasi.info/circuitjs1/vinyasi-cts -->
<html><head>
<title>Index of /circuitjs1/vinyasi-cts</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<style>
    #link_barz a:link { color:#0000dd; background-color:#ffffff; }
    #link_barz a:visited { color:#607f60; background-color:#ffffff; }
    #link_barz a:hover { color:#ff0000; background-color:#ffff00; }
    #link_barz a:active { color:#ff0000; background-color:#ffff00; }
</style>
</head>
<body bgcolor="white">
<center>
<h1>
<span style=\"color:black;\">Index of /circuitjs1/vinyasi-cts</span>
 
<img src="http://vinyasi.info/smilies/sideways.gif" alt="sideways.gif" align="bottom" width="28" height="28" border="0" />
</h1>
</center>
<p id="link_barz" style="width:70%;margin-left: auto;margin-right: auto;">
<a href="http://vinyasi.info/circuitjs1/graphs/overunity-breakthrough.txt_.html" title="http://vinyasi.info/circuitjs1/graphs/overunity-breakthrough.txt_.html">Visit this list of my circuits</a> (not Paul Falstad's) which have retained their overunity despite having series resistance added to all of the capacitors, coils and transformers. The very good ones are highlighted with a pale yellow background. Since capacitors don't vary their series resistance with respect to their capacitance, but vary according to their dielectric material &ndash; or vacuum, you can temporarily edit a capacitor's series resistance per component from its default value of 10 milli ohms, but you won't be allowed to export (save) this modification. In contrast, all of the coils and transformers have a preset value of series resistance (rated in ohms) four times their inductance in Henrys. <a href="http://is.gd/overunity" title="http://is.gd/overunity">Here is an easy to remember shortcut</a> to this list.
</p>
<div id="link_barz" align="left">
<table cellspacing="3" cellpadding="5" border="1">
<tr>
<th>
Name
</th>
<th>
Last modified
</th>
<th>
Size
</th>
<th>
Description
</th>
</tr>
<tr>
<td colspan="4" style="font-weight:bold;">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
<a href="http://vinyasi.info/circuitjs1/">Parent Directory</a>
&nbsp;&ndash;&nbsp;
Sorted in order of latest first, oldest last.
</td>
</tr>
<?PHP
  function sortByOrder($a, $b) {
    return $b['lastmod'] - $a['lastmod'];
  }
  usort($dirlist, 'sortByOrder');
  // output file list
  foreach($dirlist as $file) {
    $alt = $file['name'];
    $alt = ltrim($alt,"./");
    $moddate = date("d F Y - h:i:sa", filemtime($alt));
    $desc = "";
    if (strpos($alt,".cmf") > 0) {
      $desc = "<a href='https://sourceforge.net/projects/circuitmod/' target='_blank'>Download CircuitMod</a> and install <a href='http://java.com/' target='_blank'>Java</a> on your PC to run this file.";
    } else if(strpos($alt,".txt") > 0) {
      $desc = "Run <a href='http://vinyasi.info/ne?startCircuit=" . $alt . "' title='Run this circuit in the simulator devoid of any functional modifications made by me.'>" . $alt . "</a> in the simulator.<br />Run <a href='http://vinyasi.info/realsim?startCircuit=" . $alt . "' title='Run this circuit in a more realistic simulator in which all of the capacitors and coils have an internalized series resistance added to them.'>" . $alt . "</a> in the <i>realistic simulator</i>.<br />Run <a href='http://vinyasi.info/stepsim?startCircuit=" . $alt . "' title='Run this circuit in the step simulator in which you have to repeatedly click the RUN button in the upper right corner to step the simulation through each time frame. This simulator also has series resistance added to its caps and coils.'>" . $alt . "</a> in the <i>step simulator</i>.";
    } else if(strpos($alt,".jpg") > 0 || strpos($alt,".gif") > 0 || strpos($alt,".png") > 0) {
      $desc = "This is a picture.";
    }
    echo "<tr><td>\n";
    echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"{$file['name']}\">{$alt}</a>\n";
    echo "</td><td>\n";
    echo "{$moddate}\n";
    echo "</td><td>\n";
    echo "{$file['size']}\n";
    echo "</td><td>\n";
    echo "{$desc}\n";
    echo "</td></tr>\n";
  }
?>
</table>
<hr></div>
</body>
</html>
